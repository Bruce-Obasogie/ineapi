function S = ds_make_scenarios(Ts)
%DS_MAKE_SCENARIOS  Synthetic 24-hour test scenarios for the DampSense engine.
%   S = ds_make_scenarios(30) returns a struct array, one element per
%   scenario, sampled every Ts seconds (default 30 s), from 12:00 to 12:00
%   the next day so the cold night sits in the middle of the run. Each element holds
%   t (s), Troom, RHroom, Tcold (degC/%), gap (cm), occ (0..1), air (index)
%   plus a description and the behaviour the design expects.
%   Fixed random seed => repeatable results for the report.

if nargin < 1, Ts = 30; end
rng(7);
t  = (0:Ts:24*3600 - Ts)';           % seconds since the start of the run
h  = mod(12 + t / 3600, 24);          % clock hour: runs 12:00 -> 12:00 next day
N  = numel(t);
nz = @(s) s * randn(N, 1);            % sensor noise

% ---- Baseline: heated, occupied UK flat in winter ------------------------
base.Troom  = 20 + 1.0 * sin(2*pi*(h - 9)/24) + nz(0.15);
base.RHroom = 52 + 4 * sin(2*pi*(h - 20)/24) + nz(0.8);
base.Tcold  = 15.5 + 0.8 * sin(2*pi*(h - 14)/24) + nz(0.3);   % window frame
base.gap    = 8 + nz(0.3);                                     % sash closed ~8 cm
base.occ    = double(h >= 7 & h < 9 | h >= 17 | h < 7) .* (0.3 + 0.2 * rand(N, 1));
base.air    = 300 + 15 * sin(2*pi*(h - 20)/24) + nz(4);

S = struct([]);

% S1 Normal day
S = addS(S, 'S1_normal', base, 'Normal heated day, no moisture event', ...
         'GREEN throughout');

% S2 Shower / cooking burst 08:00-08:40
x = base;
ev = h >= 8 & h < 8 + 40/60;
x.RHroom(ev) = 86 + 1.0 * randn(sum(ev), 1);
x.Troom(ev)  = x.Troom(ev) + 1.5;
x.air(ev)    = x.air(ev) + 60;
x.occ(ev)    = 0.6;
S = addS(S, 'S2_shower', x, '40-minute shower/cooking burst at 08:00', ...
         'AMBER quickly, RED only if it persists, back to GREEN after');

% S3 Cold night, bedroom sealed 22:00-07:00, occupied
x = base;
ev = h >= 22 | h < 7;
x.Troom(ev)  = 17.5 + 0.15 * randn(sum(ev), 1);
x.RHroom(ev) = 72 + 1.0 * randn(sum(ev), 1);
x.Tcold(ev)  = 10.5 + 0.3 * randn(sum(ev), 1);
x.air(ev)    = 300 + 120 * min(1, mod(h(ev) - 22, 24) / 3) + 4 * randn(sum(ev), 1);
x.occ(ev)    = 0.25;
S = addS(S, 'S3_cold_night', x, 'Sealed bedroom on a cold night, 2 occupants', ...
         'AMBER then RED within the hour; ESCALATED after 6 h of RED');

% S4 Same night, window opened 07:00-07:20, then normal
x2 = x;
ev = h >= 7 & h < 7 + 20/60;
x2.gap(ev)    = 35 + 0.5 * randn(sum(ev), 1);
x2.RHroom(ev) = linspace(70, 52, sum(ev))' + 0.8 * randn(sum(ev), 1);
x2.Tcold(ev)  = 11 + 0.3 * randn(sum(ev), 1);
S = addS(S, 'S4_ventilate', x2, 'S3 night, window opened at 07:00 for 20 min', ...
         'VENTILATING (buzzer off) while open, then GREEN');

% S5 Cold-spot sensor failure 15:00-15:30
x = base;
ev = h >= 15 & h < 15.5;
x.Tcold(ev) = NaN;
S = addS(S, 'S5_sensor_fault', x, 'DHT11 returns no data for 30 min', ...
         'FAULT during the outage, GREEN after');

% S6 Same cold night but nobody home
x = S(3);
x.occ(:) = 0;
S = addS(S, 'S6_unoccupied', x, 'S3 conditions with the flat empty', ...
         'AMBER only (no buzzer for an empty room); ESCALATED after 6 h');

% S7 Cold external wall, MODERATE room humidity (RQ1: room-RH alarms miss it)
x = base;
ev = h >= 22 | h < 7;
x.Troom(ev)  = 18 + 0.15 * randn(sum(ev), 1);
x.RHroom(ev) = 62 + 1.0 * randn(sum(ev), 1);
x.Tcold(ev)  = 8.5 + 0.3 * randn(sum(ev), 1);
x.occ(ev)    = 0.25;
S = addS(S, 'S7_cold_wall', x, 'Room RH only ~62% but the window frame is at 8.5 C', ...
         'RED although room RH never reaches 70% (a room-RH alarm stays silent)');

for k = 1:numel(S)
    S(k).t = t; S(k).clock = h; S(k).Ts = Ts;
end
end

function S = addS(S, name, x, desc, expect)
k = numel(S) + 1;
S(k).name   = name;
S(k).Troom  = x.Troom;  S(k).RHroom = min(max(x.RHroom, 0), 100);
S(k).Tcold  = x.Tcold;  S(k).gap    = x.gap;
S(k).occ    = x.occ;    S(k).air    = x.air;
S(k).desc   = desc;     S(k).expect = expect;
end
