%DS_BUILD_SIMULINK  Build and run the DampSense Simulink model, then verify it.
%
%   Creates DampSense_RiskModel.slx programmatically:
%     6 From Workspace sources (sensor streams) -> MATLAB Function "RiskEngine"
%     (ring buffers + ds_risk_engine) -> To Workspace + Scope.
%   Runs every scenario from ds_make_scenarios, then checks the Simulink
%   output against the plain-MATLAB reference sample by sample.
%   Needs: Simulink. Keep this file in the same folder as ds_risk_engine.m
%   and ds_default_params.m (the MATLAB Function block calls them).
%
%   If the programmatic build fails on your release, build the same model
%   by hand following SIMULATION_GUIDE.md section 4 - the block code is
%   printed by this script (variable blockCode).

clear; clc;
mdl = 'DampSense_RiskModel';
Ts  = 30;
W   = 120;                    % 60 min window at 30 s
N24 = 2880;                   % 24 h at 30 s

% ------------------------- MATLAB Function block code ---------------------
blockCode = sprintf([ ...
'function [state, risk, RHs, margin] = RiskEngine(Troom, RHroom, Tcold, gap, occ, air)\n' ...
'%% Ring buffers give the engine the same 60-min window as the cloud.\n' ...
'W = %d; N24 = %d; Ts = %d;\n' ...
'persistent bT bRH bC bG bO bA hiHist prev\n' ...
'if isempty(bT)\n' ...
'    bT = nan(W,1); bRH = nan(W,1); bC = nan(W,1);\n' ...
'    bG = nan(W,1); bO = nan(W,1);  bA = nan(W,1);\n' ...
'    hiHist = false(N24,1); prev = 0;\n' ...
'end\n' ...
'bT = [bT(2:end); Troom]; bRH = [bRH(2:end); RHroom]; bC = [bC(2:end); Tcold];\n' ...
'bG = [bG(2:end); gap];   bO = [bO(2:end); occ];      bA = [bA(2:end); air];\n' ...
'P  = ds_default_params();\n' ...
'hh = sum(hiHist) * Ts / 3600;\n' ...
'[state, risk, ~, RHs, margin] = ds_risk_engine(bT, bRH, bC, bG, bO, bA, prev, hh, P);\n' ...
'hiHist = [hiHist(2:end); risk >= P.redOn];\n' ...
'prev = state;\n' ...
'end\n'], W, N24, Ts);

% ------------------------------ Build -------------------------------------
if bdIsLoaded(mdl), close_system(mdl, 0); end
if exist([mdl '.slx'], 'file'), delete([mdl '.slx']); end
new_system(mdl); open_system(mdl);
set_param(mdl, 'SolverType', 'Fixed-step', 'Solver', 'FixedStepDiscrete', ...
          'FixedStep', num2str(Ts), 'StopTime', num2str(24*3600 - Ts));

ins = {'Troom', 'RHroom', 'Tcold', 'gap', 'occ', 'air'};
for i = 1:numel(ins)
    y = 40 + 70 * (i - 1);
    add_block('simulink/Sources/From Workspace', [mdl '/' ins{i}], ...
        'VariableName', ['in_' ins{i}], 'SampleTime', num2str(Ts), ...
        'Interpolate', 'off', 'OutputAfterFinalValue', 'Holding final value', ...
        'Position', [40 y 140 y + 30]);
end
add_block('simulink/User-Defined Functions/MATLAB Function', [mdl '/RiskEngine'], ...
          'Position', [300 40 470 440]);
rt  = sfroot;
bd  = rt.find('-isa', 'Simulink.BlockDiagram', 'Name', mdl);
chart = bd.find('-isa', 'Stateflow.EMChart', 'Name', 'RiskEngine');
chart.Script = blockCode;

outs = {'state', 'risk', 'RHs', 'margin'};
for i = 1:numel(outs)
    y = 60 + 90 * (i - 1);
    add_block('simulink/Sinks/To Workspace', [mdl '/out_' outs{i}], ...
        'VariableName', ['sl_' outs{i}], 'SaveFormat', 'Timeseries', ...
        'Position', [600 y 700 y + 30]);
end
add_block('simulink/Sinks/Scope', [mdl '/Scope'], 'NumInputPorts', '4', ...
          'Position', [600 420 640 520]);

for i = 1:numel(ins)
    add_line(mdl, [ins{i} '/1'], ['RiskEngine/' num2str(i)], 'autorouting', 'on');
end
for i = 1:numel(outs)
    add_line(mdl, ['RiskEngine/' num2str(i)], ['out_' outs{i} '/1'], 'autorouting', 'on');
    add_line(mdl, ['RiskEngine/' num2str(i)], ['Scope/' num2str(i)],  'autorouting', 'on');
end
save_system(mdl);
fprintf('Built %s.slx\n', mdl);

% ------------------------- Run every scenario -----------------------------
P = ds_default_params();
S = ds_make_scenarios(Ts);
check = table();
if ~exist('results', 'dir'), mkdir results; end
for s = 1:numel(S)
    d = S(s);
    for i = 1:numel(ins)
        assignin('base', ['in_' ins{i}], timeseries(d.(ins{i}), d.t));
    end
    out = sim(mdl);
    slState = squeeze(out.sl_state.Data);
    slRisk  = squeeze(out.sl_risk.Data);

    % reference: same algorithm in plain MATLAB
    N = numel(d.t); refState = zeros(N, 1); refRisk = nan(N, 1); prev = P.GREEN;
    for k = 1:N
        w  = max(1, k - W + 1):k;
        hh = sum(refRisk(max(1, k - N24):k - 1) >= P.redOn) * Ts / 3600;
        [refState(k), refRisk(k)] = ds_risk_engine(d.Troom(w), d.RHroom(w), d.Tcold(w), ...
            d.gap(w), d.occ(w), d.air(w), prev, hh, P);
        prev = refState(k);
    end
    n  = min(numel(slState), N);
    mism = sum(slState(1:n) ~= refState(1:n));
    dr   = max(abs(slRisk(1:n) - refRisk(1:n)), [], 'omitnan');
    check = [check; {string(d.name), n, mism, dr}]; %#ok<AGROW>

    f = figure('Visible', 'off', 'Position', [100 100 900 420]);
    stairs(d.t(1:n) / 3600, slState(1:n), 'LineWidth', 1.5); hold on;
    plot(d.t(1:n) / 3600, refState(1:n), 'r:', 'LineWidth', 1.2);
    yticks(0:5); yticklabels({'GREEN','AMBER','RED','VENT','ESC','FAULT'}); ylim([-0.5 5.5]);
    xlabel('Hours from 12:00'); legend('Simulink', 'MATLAB reference'); grid on;
    title(strrep(d.name, '_', ' ') + " - Simulink vs reference");
    exportgraphics(f, fullfile('results', "SL_" + d.name + ".png"), 'Resolution', 150);
    close(f);
end
check.Properties.VariableNames = {'Scenario', 'Samples', 'StateMismatches', 'MaxRiskDiff'};
disp(check);
writetable(check, fullfile('results', 'simulink_vs_reference.csv'));
