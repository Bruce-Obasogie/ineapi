function [state, risk, TdNow, RHsNow, marginNow] = ds_risk_engine( ...
            Troom, RHroom, Tcold, gap, occ, air, prevState, hoursHigh24, P)
%DS_RISK_ENGINE  DampSense central decision logic (pure function, no I/O).
%
%   Inputs are column vectors covering the analysis window, oldest first.
%   NaN marks a missing reading. prevState is the last state sent to the
%   device (for hysteresis); hoursHigh24 is how long risk was >= P.redOn in
%   the last 24 h.
%
%   Outputs: state code (see ds_default_params), risk score 0..100,
%   current dew point TdNow (degC), surface RH at the cold spot RHsNow (%)
%   and condensation margin marginNow = Tcold - Td (degC).
%
%   Used unchanged by: ds_run_offline.m (MATLAB), the Simulink model
%   (MATLAB Function block) and ThingSpeak_CentralUnit.m (cloud).
%#codegen

risk = NaN; TdNow = NaN; RHsNow = NaN; marginNow = NaN;

valid = ~isnan(Troom) & ~isnan(RHroom) & ~isnan(Tcold);
n = numel(valid);
lastK = max(1, n - 2):n;                       % newest 3 samples
if sum(valid) < P.minValid || ~any(valid(lastK))
    state = P.FAULT;
    return;
end

% ---- Psychrometrics -----------------------------------------------------
rh    = min(max(RHroom, 1), 100);
gam   = log(rh / 100) + P.a .* Troom ./ (P.b + Troom);
Td    = P.b .* gam ./ (P.a - gam);                                   % dew point
RHs   = 100 .* exp(P.a .* Td ./ (P.b + Td)) ./ exp(P.a .* Tcold ./ (P.b + Tcold));
RHs   = min(RHs, 100);                                               % >=100 => condensing
Td(~valid) = NaN;  RHs(~valid) = NaN;

idx       = lastK(valid(lastK));
RHsNow    = median(RHs(idx));
TdNow     = median(Td(idx));
marginNow = median(Tcold(idx)) - TdNow;

% ---- Component scores ---------------------------------------------------
Sa = min(max((RHsNow - P.rhsLow) / (P.rhsHigh - P.rhsLow) * 100, 0), 100);
Sp = 100 * sum(RHs(valid) >= P.mouldRH) / sum(valid);

Sv = 0;
va = air(~isnan(air));
if numel(va) >= 3
    s    = sort(va);
    base = s(max(1, ceil(0.1 * numel(s))));     % 10th percentile = fresh-air baseline
    aNow = median(va(max(1, numel(va) - 2):end));
    Sv   = min(max((aNow - base) / max(base, 1) / P.airSpan * 100, 0), 100);
end

risk = P.wS * Sa + P.wP * Sp + P.wV * Sv;

% ---- Level with hysteresis ----------------------------------------------
prevLevel = 0;
if prevState == P.AMBER
    prevLevel = 1;
elseif prevState == P.RED || prevState == P.ESCALATED || prevState == P.VENTILATING
    prevLevel = 2;
end
level = 0;
if risk >= P.redOn
    level = 2;
elseif risk >= P.amberOn
    level = 1;
end
if prevLevel == 2 && level < 2 && risk >= P.redOff
    level = 2;
end
if prevLevel >= 1 && level == 0 && risk >= P.amberOff
    level = 1;
end

% ---- Context: window and occupancy --------------------------------------
g = gap(lastK); g = g(~isnan(g));
windowOpen = ~isempty(g) && median(g) > P.gapOpenCm;
o = occ(max(1, numel(occ) - P.occRecentN + 1):end);
o = o(~isnan(o));
occupied = ~isempty(o) && any(o > P.occMinFrac);

% ---- Decision -----------------------------------------------------------
if level == 0
    state = P.GREEN;
elseif windowOpen
    state = P.VENTILATING;                 % occupant already acting: no buzzer
elseif level == 2 && hoursHigh24 >= P.escalateHours
    state = P.ESCALATED;                   % persistent problem: notify landlord
elseif level == 2 && occupied
    state = P.RED;                         % someone present who can ventilate
else
    state = P.AMBER;                       % rising risk, or high risk but nobody home
end
end
