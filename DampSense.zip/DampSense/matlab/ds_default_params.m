function P = ds_default_params()
%DS_DEFAULT_PARAMS  Tunable parameters of the DampSense risk engine.
%   One source of truth for MATLAB, Simulink and (copied into) ThingSpeak.
%#codegen

% --- Magnus dew-point constants (over water, -45..60 C; Alduchov & Eskridge 1996)
P.a = 17.62;
P.b = 243.12;            % degC

% --- Surface-humidity scoring
P.rhsLow   = 65;         % % surface RH that starts to score
P.rhsHigh  = 90;         % % surface RH that scores 100
P.mouldRH  = 80;         % % IEA Annex 14 germination threshold (sustained)

% --- Air staleness (MQ-135 relative index)
P.airSpan  = 0.5;        % +50 % above the window baseline scores 100

% --- Weights (sum to 1)
P.wS = 0.50;             % surface RH now
P.wP = 0.35;             % persistence of surface RH >= mouldRH in window
P.wV = 0.15;             % air staleness

% --- State thresholds with hysteresis
P.amberOn  = 40;  P.amberOff = 30;
P.redOn    = 70;  P.redOff   = 60;

% --- Context
P.gapOpenCm     = 20;    % HC-SR04 reading above this = window open (calibrate on your build)
P.occRecentN    = 20;    % samples checked for occupancy (20 x 30 s = 10 min)
P.occMinFrac    = 0.05;  % PIR high fraction counted as "occupied"
P.escalateHours = 6;     % RED-level hours in the last 24 h that trigger escalation
P.minValid      = 3;     % valid samples needed, otherwise FAULT

% --- State codes (must match firmware enum)
P.GREEN = 0; P.AMBER = 1; P.RED = 2; P.VENTILATING = 3; P.ESCALATED = 4; P.FAULT = 5;
end
