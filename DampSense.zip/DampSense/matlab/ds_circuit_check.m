%DS_CIRCUIT_CHECK  Electrical design checks for the DampSense node.
%   Simulates the two level-shifting dividers, the LED and buzzer drive
%   circuits and the 5 V power budget. Prints a table and saves figures
%   to ./results for the Design and Test sections.
%   Plain MATLAB. (An optional Simscape version is described in
%   SIMULATION_GUIDE.md section 5.)

clear; clc;
if ~exist('results', 'dir'), mkdir results; end
par = @(a, b) a .* b ./ (a + b);

% ---------------- 1. HC-SR04 ECHO -> D2 (GPIO4) -------------------------
R1 = 1e3; R2 = 2e3;                     % 1k top, 2 x 1k in series bottom
VinE  = 5.0;
VoutE = VinE * R2 / (R1 + R2);
% ESP8266EX: VIH min 0.75*VDD, max VDD+0.3 (datasheet)
VIHmin = 0.75 * 3.3; VIHmax = 3.3 + 0.3;
fprintf('ECHO divider: %.2f V out (logic-high window %.2f..%.2f V) -> %s\n', ...
        VoutE, VIHmin, VIHmax, okStr(VoutE >= VIHmin && VoutE <= VIHmax));

% Echo pulse simulation (object at 10 cm => ~583 us high)
fs = 1e6; t = (0:1/fs:2e-3)';
d  = 0.10; tHigh = 2 * d / 343;
echo5 = VinE * (t >= 0.2e-3 & t < 0.2e-3 + tHigh);
echo3 = echo5 * R2 / (R1 + R2);
f = figure('Visible', 'off', 'Position', [100 100 800 300]);
plot(t * 1e3, echo5, t * 1e3, echo3, 'LineWidth', 1.2); hold on;
yline(VIHmin, ':', 'V_{IH} min'); yline(VIHmax, ':', 'V_{max}');
xlabel('Time (ms)'); ylabel('Voltage (V)'); ylim([-0.2 5.5]); grid on;
legend('HC-SR04 ECHO (5 V)', 'At ESP8266 D2', 'Location', 'northeast');
title('Echo level shift: 5 V pulse to 3.33 V (object at 10 cm)');
exportgraphics(f, fullfile('results', 'circuit_echo_divider.png'), 'Resolution', 150); close(f);

% ---------------- 2. MQ-135 AOUT -> A0 ----------------------------------
% D1 mini / NodeMCU boards already carry a 220k/100k divider on A0 (A0 pin
% 0..3.2 V -> ADC 0..1.0 V). Our external divider must keep A0 <= 3.2 V.
Ra = 10e3; Rb = 14.7e3;                 % 10k top, 10k + 4.7k bottom
Rboard = 220e3 + 100e3;                 % on-board divider seen as a load
Vaq  = linspace(0, 5, 101)';
Rbe  = par(Rb, Rboard);
VA0  = Vaq * Rbe / (Ra + Rbe);
adc  = min(round(VA0 / 3.2 * 1023), 1023);
fprintf('MQ-135 divider: 5.00 V sensor -> %.2f V at A0 (limit 3.2 V) -> %s, ADC %d\n', ...
        VA0(end), okStr(VA0(end) <= 3.2), adc(end));
f = figure('Visible', 'off', 'Position', [100 100 800 300]);
yyaxis left;  plot(Vaq, VA0, 'LineWidth', 1.2); ylabel('Voltage at A0 (V)'); yline(3.2, ':', 'A0 limit');
yyaxis right; plot(Vaq, adc, '--', 'LineWidth', 1); ylabel('ADC count');
xlabel('MQ-135 AOUT (V)'); grid on; title('MQ-135 to A0: full 0-5 V range stays inside 0-3.2 V');
exportgraphics(f, fullfile('results', 'circuit_mq135_divider.png'), 'Resolution', 150); close(f);

% ---------------- 3. LEDs (active-low, 3.3 V) ---------------------------
Rled = 330; Vf = [2.0 2.0 2.0];         % red / amber / green typical Vf
Iled = (3.3 - Vf) / Rled * 1e3;
fprintf('LED current %.1f mA each (GPIO sink limit 12 mA) -> %s\n', Iled(1), okStr(all(Iled < 12)));

% ---------------- 4. Buzzer driver (NPN, e.g. 2N2222 / BC547) -----------
Rbase = 1e3; Vbe = 0.7; hFE = 100; Ibuz = 30e-3;
Ib = (3.3 - Vbe) / Rbase;
fprintf('Buzzer: base %.1f mA, can sink %.0f mA vs %.0f mA needed -> %s (1N4148 flyback diode across buzzer)\n', ...
        Ib * 1e3, Ib * hFE * 1e3, Ibuz * 1e3, okStr(Ib * hFE > 2 * Ibuz));

% ---------------- 5. 5 V power budget (typical datasheet values) --------
part  = ["ESP8266 (Wi-Fi TX peak)"; "MQ-135 heater"; "HC-SR04"; "DHT22"; "DHT11"; ...
         "HC-SR501"; "3 LEDs"; "Buzzer"];
mA    = [170; 150; 15; 1.5; 2.5; 0.065; sum(Iled); 30];
T = table(part, mA, 'VariableNames', {'Component', 'Peak_mA'});
disp(T);
fprintf('Total peak %.0f mA vs USB 2.0 port 500 mA -> %s\n', sum(mA), okStr(sum(mA) < 500));
writetable(T, fullfile('results', 'power_budget.csv'));

function s = okStr(ok)
if ok, s = 'PASS'; else, s = 'CHECK'; end
end
