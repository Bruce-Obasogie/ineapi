%DS_SECURITY_TESTS  Attack the actuator path and record what the node does.
%   Posts commands straight to the Command channel through the REST API,
%   acting as an attacker who has obtained the channel WRITE key (the worst
%   case: broker access alone is not enough to move the actuator).
%   Watch the node's Serial Monitor (115200 baud): each case should print
%   the reason shown in "Expected". Wait 16 s between posts (free-licence
%   rate limit). Record pass/fail in the report's Test section.

clear; clc;
CH_COMMAND        = 0000000;
WRITE_KEY_COMMAND = 'XXXXXXXXXXXXXXXX';
DEVICE_ID         = 'DS01';
HMAC_KEY          = 'k3y-CHANGE-ME-32-chars-long-0001';   % the real key (for the valid case)
WRONG_KEY         = 'attacker-guess-0000000000000000';

nowS = floor(posixtime(datetime('now', 'TimeZone', 'UTC')));
seq0 = input('Enter a sequence number HIGHER than the last accepted one (see Serial Monitor): ');

mk = @(key, st, sq, ts) sprintf('%d|%d|%d|%s', st, sq, ts, ...
        ds_hmac_sha256(key, sprintf('%s|%d|%d|%d', DEVICE_ID, st, sq, ts)));
valid = mk(HMAC_KEY, 0, seq0, nowS);

cases = {
 'T-S3a valid command (control)',      valid,                                  'accepted state=0';
 'T-S3b replay of the same command',   valid,                                  'REJECTED (replay)';
 'T-S3c forged MAC (wrong key)',       mk(WRONG_KEY, 0, seq0 + 1, nowS),       'REJECTED (bad-mac)';
 'T-S3d tampered state field',         ['1' valid(2:end)],                     'REJECTED (bad-mac)';
 'T-S3e stale command (10 min old)',   mk(HMAC_KEY, 0, seq0 + 2, nowS - 600),  'REJECTED (stale)';
 'T-S3f malformed payload',            'TURN_OFF_ALARM',                       'REJECTED (format)'};

for i = 1:size(cases, 1)
    fprintf('\n%s\n  sending: %s\n  expected on device: %s\n', cases{i, 1}, cases{i, 2}, cases{i, 3});
    webwrite('https://api.thingspeak.com/update', 'api_key', WRITE_KEY_COMMAND, 'field1', cases{i, 2});
    if i < size(cases, 1), pause(16); end
end
fprintf('\nDone. Note: T-S3a-f use the REST write key; the node itself only holds subscribe rights.\n');
