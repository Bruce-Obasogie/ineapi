%DS_HMAC_SELFTEST  Verify the MATLAB SHA-256 / HMAC implementation.
%   Run before deploying. All three lines must print PASS.
%   Vectors: FIPS 180-2 "abc", RFC 4231 test case 2, and a DampSense
%   command whose MAC was computed independently with Python's hmac module.

tests = {
  'SHA-256("abc")', ...
     lower(reshape(dec2hex(ds_sha256('abc'), 2)', 1, [])), ...
     'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad';
  'HMAC RFC 4231 #2', ...
     ds_hmac_sha256('Jefe', 'what do ya want for nothing?'), ...
     '5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843';
  'HMAC DampSense cmd', ...
     ds_hmac_sha256('k3y-CHANGE-ME-32-chars-long-0001', 'DS01|2|17|1762700000'), ...
     '37756bcf8039c51ee03c90d3d12b3bc7438840e9eb363e202b30b5a72bb4bc43'};

for i = 1:size(tests, 1)
    ok = strcmp(tests{i, 2}, tests{i, 3});
    fprintf('%-20s %s\n', tests{i, 1}, ternary(ok));
end

function s = ternary(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
