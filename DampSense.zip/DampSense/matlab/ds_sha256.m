function digest = ds_sha256(msg)
%DS_SHA256  SHA-256 (FIPS 180-4) in plain MATLAB, no toolboxes or Java.
%   digest = ds_sha256(msg) returns a 1x32 uint8 digest of msg (char or uint8).
%   Written so it also runs inside ThingSpeak MATLAB Analysis.
%   Check with ds_hmac_selftest.

msg = uint8(msg(:)');
K = uint32(hex2dec({ ...
 '428a2f98','71374491','b5c0fbcf','e9b5dba5','3956c25b','59f111f1','923f82a4','ab1c5ed5', ...
 'd807aa98','12835b01','243185be','550c7dc3','72be5d74','80deb1fe','9bdc06a7','c19bf174', ...
 'e49b69c1','efbe4786','0fc19dc6','240ca1cc','2de92c6f','4a7484aa','5cb0a9dc','76f988da', ...
 '983e5152','a831c66d','b00327c8','bf597fc7','c6e00bf3','d5a79147','06ca6351','14292967', ...
 '27b70a85','2e1b2138','4d2c6dfc','53380d13','650a7354','766a0abb','81c2c92e','92722c85', ...
 'a2bfe8a1','a81a664b','c24b8b70','c76c51a3','d192e819','d6990624','f40e3585','106aa070', ...
 '19a4c116','1e376c08','2748774c','34b0bcb5','391c0cb3','4ed8aa4a','5b9cca4f','682e6ff3', ...
 '748f82ee','78a5636f','84c87814','8cc70208','90befffa','a4506ceb','bef9a3f7','c67178f2'}))';
H = uint32(hex2dec({'6a09e667','bb67ae85','3c6ef372','a54ff53a', ...
                    '510e527f','9b05688c','1f83d9ab','5be0cd19'}))';

% ---- Padding ----
L = numel(msg);
bitLen = L * 8;
lenBytes = zeros(1, 8, 'uint8');
for i = 1:8
    lenBytes(9 - i) = uint8(mod(floor(bitLen / 256^(i - 1)), 256));
end
msg = [msg, uint8(128), zeros(1, mod(55 - L, 64), 'uint8'), lenBytes];

% ---- Compression ----
for blk = 0:(numel(msg) / 64 - 1)
    B = double(msg(blk * 64 + (1:64)));
    W = zeros(1, 64, 'uint32');
    for t = 1:16
        W(t) = uint32(B(4*t-3) * 16777216 + B(4*t-2) * 65536 + B(4*t-1) * 256 + B(4*t));
    end
    for t = 17:64
        s0 = bitxor(bitxor(rotr(W(t-15), 7), rotr(W(t-15), 18)), bitshift(W(t-15), -3));
        s1 = bitxor(bitxor(rotr(W(t-2), 17), rotr(W(t-2), 19)), bitshift(W(t-2), -10));
        W(t) = add32(W(t-16), s0, W(t-7), s1);
    end
    a = H(1); b = H(2); c = H(3); d = H(4); e = H(5); f = H(6); g = H(7); h = H(8);
    for t = 1:64
        S1  = bitxor(bitxor(rotr(e, 6), rotr(e, 11)), rotr(e, 25));
        ch  = bitxor(bitand(e, f), bitand(bitcmp(e), g));
        T1  = add32(h, S1, ch, K(t), W(t));
        S0  = bitxor(bitxor(rotr(a, 2), rotr(a, 13)), rotr(a, 22));
        maj = bitxor(bitxor(bitand(a, b), bitand(a, c)), bitand(b, c));
        T2  = add32(S0, maj);
        h = g; g = f; f = e; e = add32(d, T1);
        d = c; c = b; b = a; a = add32(T1, T2);
    end
    H = [add32(H(1), a), add32(H(2), b), add32(H(3), c), add32(H(4), d), ...
         add32(H(5), e), add32(H(6), f), add32(H(7), g), add32(H(8), h)];
end

% ---- Output big-endian bytes ----
digest = zeros(1, 32, 'uint8');
for i = 1:8
    v = double(H(i));
    digest(4*i-3:4*i) = uint8([floor(v / 16777216), mod(floor(v / 65536), 256), ...
                               mod(floor(v / 256), 256), mod(v, 256)]);
end
end

function y = rotr(x, n)
% 32-bit rotate right. The low n bits are masked before the left shift so
% nothing can overflow 32 bits, whatever the MATLAB release.
lowBits = bitand(x, uint32(2^n - 1));
y = bitor(bitshift(x, -n), bitshift(lowBits, 32 - n));
end

function s = add32(varargin)
% Addition modulo 2^32 (uint32 '+' would saturate, so add in double).
acc = 0;
for k = 1:nargin
    acc = acc + double(varargin{k});
end
s = uint32(mod(acc, 4294967296));
end
