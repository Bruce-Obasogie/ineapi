function hexMac = ds_hmac_sha256(key, msg)
%DS_HMAC_SHA256  HMAC-SHA256 (RFC 2104) returning a lowercase hex string.
%   hexMac = ds_hmac_sha256('secret', 'DS01|2|17|1762700000')

key = uint8(key(:)');
msg = uint8(msg(:)');
if numel(key) > 64
    key = ds_sha256(key);
end
key  = [key, zeros(1, 64 - numel(key), 'uint8')];
ipad = bitxor(key, uint8(54));      % 0x36
opad = bitxor(key, uint8(92));      % 0x5c
inner  = ds_sha256([ipad, msg]);
mac    = ds_sha256([opad, inner]);
hexMac = lower(reshape(dec2hex(mac, 2)', 1, []));
end
