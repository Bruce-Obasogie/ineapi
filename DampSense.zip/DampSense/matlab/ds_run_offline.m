%DS_RUN_OFFLINE  Run the DampSense decision engine over all test scenarios.
%   Plain MATLAB (no Simulink needed). Produces, in ./results:
%     - one 4-panel figure per scenario (PNG) for the report's Test section
%     - transitions.csv   every state change with its clock time
%     - summary.csv       per-scenario metrics (first AMBER/RED, max risk ...)
%   The window length and timing match the deployed ThingSpeak analysis.

clear; clc;
P     = ds_default_params();
Ts    = 30;                         % s, simulation step (= telemetry interval)
WINm  = 60;                         % analysis window, minutes
W     = WINm * 60 / Ts;             % samples in window
N24   = 24 * 3600 / Ts;             % samples in 24 h
S     = ds_make_scenarios(Ts);
names = {'GREEN','AMBER','RED','VENTILATING','ESCALATED','FAULT'};
if ~exist('results', 'dir'), mkdir results; end

trans = table(); summ = table();
for s = 1:numel(S)
    d = S(s); N = numel(d.t);
    state = zeros(N, 1); risk = nan(N, 1); RHs = nan(N, 1); Td = nan(N, 1); margin = nan(N, 1);
    prev = P.GREEN;
    for k = 1:N
        w  = max(1, k - W + 1):k;
        hh = sum(risk(max(1, k - N24):k - 1) >= P.redOn) * Ts / 3600;
        [state(k), risk(k), Td(k), RHs(k), margin(k)] = ds_risk_engine( ...
            d.Troom(w), d.RHroom(w), d.Tcold(w), d.gap(w), d.occ(w), d.air(w), prev, hh, P);
        prev = state(k);
    end

    % ---- transitions ----
    idx = [1; find(diff(state) ~= 0) + 1];
    for i = idx'
        trans = [trans; {string(d.name), string(clockStr(d.clock(i))), ...
                         string(names{state(i) + 1}), round(risk(i), 1)}]; %#ok<AGROW>
    end
    firstOf = @(code) firstClock(d.clock, state, code);
    % RQ2 baseline: a conventional hygrometer alarm sounding whenever room RH >= 70 %
    baseMin    = sum(d.RHroom >= 70) * Ts / 60;
    audibleMin = sum(state == P.RED | state == P.ESCALATED) * Ts / 60;
    summ = [summ; {string(d.name), string(d.expect), firstOf(P.AMBER), firstOf(P.RED), ...
                   firstOf(P.VENTILATING), firstOf(P.ESCALATED), firstOf(P.FAULT), ...
                   round(max(risk), 1), round(max(d.RHroom), 1), round(max(RHs), 1), ...
                   numel(idx) - 1, baseMin, audibleMin}]; %#ok<AGROW>

    % ---- figure ----
    hrs = d.t / 3600;
    f = figure('Visible', 'off', 'Position', [100 100 900 900]);
    tl = tiledlayout(4, 1, 'TileSpacing', 'compact');
    title(tl, strrep(d.name, '_', ' ') + ": " + d.desc);
    nexttile; plot(hrs, d.RHroom, hrs, RHs, 'LineWidth', 1); yline(P.mouldRH, '--', '80% mould threshold');
    ylabel('RH (%)'); legend('Room RH', 'Surface RH at cold spot', 'Location', 'best'); grid on;
    nexttile; plot(hrs, d.Troom, hrs, d.Tcold, hrs, Td, 'LineWidth', 1);
    ylabel('Temperature (\circC)'); legend('Room', 'Cold spot', 'Dew point', 'Location', 'best'); grid on;
    nexttile; plot(hrs, risk, 'k', 'LineWidth', 1.2);
    yline(P.amberOn, '--', 'Amber 40'); yline(P.redOn, '--', 'Red 70');
    ylabel('Risk (0-100)'); ylim([0 100]); grid on;
    nexttile; stairs(hrs, state, 'LineWidth', 1.5); yticks(0:5); yticklabels(names); ylim([-0.5 5.5]);
    xlabel('Hours from 12:00'); grid on;
    exportgraphics(f, fullfile('results', d.name + ".png"), 'Resolution', 150);
    close(f);
end

trans.Properties.VariableNames = {'Scenario','Clock','State','Risk'};
summ.Properties.VariableNames  = {'Scenario','Expected','FirstAmber','FirstRed', ...
                                  'FirstVentilating','FirstEscalated','FirstFault','MaxRisk', ...
                                  'MaxRoomRH','MaxSurfaceRH','StateChanges', ...
                                  'BaselineAlarmMin','EngineAudibleMin'};
writetable(trans, fullfile('results', 'transitions.csv'));
writetable(summ,  fullfile('results', 'summary.csv'));
disp(summ);
fprintf('Figures and CSVs written to %s\n', fullfile(pwd, 'results'));

% ---------------------------------------------------------------------------
function s = clockStr(hr)
m = round(hr * 60);
s = sprintf('%02d:%02d', mod(floor(m / 60), 24), mod(m, 60));
end

function s = firstClock(clock, state, code)
i = find(state == code, 1);
if isempty(i), s = "-"; else, s = string(clockStr(clock(i))); end
end
