# DampSense — Build, Simulation and Test Guide

Follow the sections in order. Every test ID (T-xx) matches the test plan in Section 5 of the report. Paste each result into the report placeholder marked with the same ID.

---

## 0. What you need

| Item | Version / note |
|---|---|
| Arduino IDE | 2.x. In Boards Manager add `https://arduino.esp8266.com/stable/package_esp8266com_index.json` and install **esp8266** |
| Libraries (Library Manager) | PubSubClient (Nick O'Leary) ≥ 2.8 · ArduinoJson ≥ 7 · DHT sensor library (Adafruit) + Adafruit Unified Sensor |
| MATLAB | R2021a or later (uses `tiledlayout`, `exportgraphics`). Simulink for section 4. Simscape Electrical is optional (section 5) |
| ThingSpeak | Free MathWorks account: 4 channels, 15 s minimum update interval |
| Other | Wireshark (security tests), MQTTX desktop client (security tests), a phone or laptop hotspot you control |

Folder layout of the delivered pack:

```
DampSense/
  firmware/DampSense_Node/   DampSense_Node.ino, secrets_template.h
  matlab/                    engine, scenarios, Simulink builder, circuit + security tests
  thingspeak/                ThingSpeak_CentralUnit.m, ThingSpeak_Visualization.m
  docs/                      this guide
```

---

## 1. ThingSpeak set-up (about 20 minutes)

1. **Create three channels** (Channels > New Channel). Tick the fields and name them exactly:

| Channel | Field 1 | Field 2 | Field 3 | Field 4 | Field 5 | Field 6 | Field 7 | Field 8 |
|---|---|---|---|---|---|---|---|---|
| 1 DampSense-Telemetry | Room temp (°C) | Room RH (%) | Cold-spot temp (°C) | Window gap (cm) | Occupancy (0–1) | Air index | RSSI (dBm) | Sequence |
| 2 DampSense-Analysis | Dew point (°C) | Surface RH (%) | Condensation margin (°C) | Risk (0–100) | State | High-risk hours (24 h) | Packet delivery (%) | Data age (s) |
| 3 DampSense-Command | Command | – | – | – | – | – | – | – |

   Keep all three channels **Private**. Note each channel ID, its Read API key and its Write API key.

2. **Create the MQTT device** (Devices > MQTT > Add a new device). Authorise:
   - Channel 1 — **Allow Publish** only
   - Channel 3 — **Allow Subscribe** only

   Download the credentials (Client ID, Username, Password). This is the least-privilege rule: the node can never write commands.

3. **Get the TLS root certificate**: open `https://thingspeak.com` in Chrome/Edge → padlock → *Connection is secure* → *Certificate is valid* → *Details* → select the **top** (root) certificate → *Export* (Base-64 / PEM). Paste it into `secrets.h`.

4. **Generate the shared HMAC key** in MATLAB: `key = char(randi([48 122], 1, 32))`. Use the same 32 characters in `secrets.h` and in `ThingSpeak_CentralUnit.m`. Never commit it.

---

## 2. Hardware build

### 2.1 Wiring (D1 mini / NodeMCU pin labels)

| Part | Part pin | Connects to | Notes |
|---|---|---|---|
| DHT22 (room) | VCC / DATA / GND | 3V3 / **D5** / GND | 10 kΩ DATA→3V3 if the bare sensor has no pull-up |
| DHT11 (cold spot) | VCC / DATA / GND | 3V3 / **D6** / GND | Mount on the model window "glass" |
| HC-SR501 PIR | VCC / OUT / GND | 5V / **D7** / GND | OUT is 3.3 V logic; set delay pot minimum, jumper on repeat (H) |
| HC-SR04 | VCC / TRIG / ECHO / GND | 5V / **D1** / divider / GND | ECHO → 1 kΩ → **D2**; D2 → 2 kΩ (2 × 1 kΩ) → GND |
| MQ-135 module | VCC / AOUT / GND | 5V / divider / GND | AOUT → 10 kΩ → **A0**; A0 → 14.7 kΩ (10 k + 4.7 k) → GND |
| Green LED | anode / cathode | 3V3 via 330 Ω / **D0** | active-low |
| Amber LED | anode / cathode | 3V3 via 330 Ω / **D3** | active-low (keeps D3 high at boot) |
| Red LED | anode / cathode | 3V3 via 330 Ω / **D4** | active-low (keeps D4 high at boot) |
| Passive buzzer | + / − | 5V / NPN collector | 1N4148 across buzzer (cathode to 5V) |
| NPN (2N2222/BC547) | B / E | **D8** via 1 kΩ / GND | D8 must be low at boot — the base resistor keeps it so |

Check on your board: if it is **not** a D1 mini/NodeMCU-style board (no on-board A0 divider), A0 accepts only 0–1.0 V. Then change the MQ-135 divider to 47 kΩ top / 10 kΩ bottom.

### 2.2 Build order (photograph every step for the Implementation section)

1. Base plate: 300 × 400 mm plywood or acrylic. Print and stick a layout drawing.
2. Model "room corner": a hinged 100 × 80 mm acrylic "window" on one edge.
3. Mount the breadboard (or stripboard) and the ESP8266 with M3 stand-offs.
4. Mount the HC-SR04 on the window frame facing the sash (~8 cm when closed). DHT11 glued to the "glass".
5. DHT22, PIR and MQ-135 on the "wall" side, ≥ 5 cm from the MQ-135 heater.
6. LEDs in a row with a printed GREEN / AMBER / RED legend; buzzer beside them.
7. Wire with colour code: red 5V, orange 3V3, black GND, other colours for signals. Label every wire end.
8. Cable ties, and a single USB lead to a 5 V 2 A supply.

### 2.3 Measure before you power the ESP8266 (T-H1)
With a multimeter, feed 5 V into the ECHO divider input and the MQ-135 divider input. Record the voltages at D2 and A0. Expected: 3.33 V and ≤ 3.0 V.

---

## 3. Firmware

1. Copy `secrets_template.h` to `secrets.h`, fill every value.
2. Board: *LOLIN(WEMOS) D1 mini* or *NodeMCU 1.0*. Upload speed 115200 or 921600.
3. Upload `DampSense_Node.ino`. Open Serial Monitor at 115200 baud.
4. Expected log: `Wi-Fi ok` → `NTP ok` → `MQTT ... connected, subscribed channels/<id>/subscribe` → a `[TX] ok field1=...` line every 20 s.
5. Calibrate the window threshold: read `field4` with the window closed and open. Set `P.gapOpenCm` (in `ds_default_params.m`) halfway between, then rebuild the ThingSpeak script.
6. MQ-135: leave powered for at least 24 h before recording results (heater burn-in).

Commit to Git: create a private repo, add `.gitignore` with `secrets.h` and `results/`, commit after every working step with a clear message (e.g. `feat: HMAC command verification`). Screenshot the commit history for the report.

---

## 4. MATLAB and Simulink simulations

Set MATLAB's current folder to `DampSense/matlab`.

### 4.1 Crypto self-test (T-S0)
```matlab
ds_hmac_selftest
```
All three lines must print `PASS`. Screenshot.

### 4.2 Decision engine over seven scenarios (T-F5 … T-F9, RQ1, RQ2)
```matlab
ds_run_offline
```
Produces `results/S1_normal.png … S7_cold_wall.png`, `transitions.csv`, `summary.csv`. Behaviour the design predicts (from an independent re-implementation used while designing — confirm with your own run):

| Scenario | Predicted behaviour |
|---|---|
| S1 normal | GREEN all day (risk stays near 20) |
| S2 shower 08:00–08:40 | AMBER at 08:00, RED ~08:23, AMBER 08:40, GREEN ~09:05 |
| S3 cold night | AMBER 22:00, RED 22:30, ESCALATED 04:30, GREEN ~07:27 |
| S4 window opened 07:00 | as S3, then VENTILATING 07:00–07:21, GREEN ~07:45 |
| S5 sensor fault 15:00–15:30 | FAULT 15:01–15:30 |
| S6 unoccupied | AMBER only (no RED, no buzzer) until ESCALATED 04:30 |
| S7 cold wall | AMBER 22:00, RED ~22:32, ESCALATED ~04:33 — while room RH never exceeds ~66% |

`summary.csv` also gives, per scenario, `BaselineAlarmMin` (minutes a conventional room-RH ≥ 70 % alarm would sound) and `EngineAudibleMin` (minutes DampSense actually sounds). Use these two columns for RQ2, and MaxRoomRH vs MaxSurfaceRH in S7 for RQ1.

The first two samples of every run show FAULT: the engine needs three valid samples. That is expected start-up behaviour; mention it.

### 4.3 Simulink model (T-F10)
```matlab
ds_build_simulink
```
Builds `DampSense_RiskModel.slx`, runs all six scenarios and writes `results/simulink_vs_reference.csv`. **Pass = 0 state mismatches** for every scenario. Open the model and screenshot the diagram and the Scope for S3 (the report needs both).

If the programmatic build fails, build it by hand:
1. New blank model. *Model Settings > Solver*: Fixed-step, discrete, step size 30, stop time 86370.
2. Add six **From Workspace** blocks named Troom, RHroom, Tcold, gap, occ, air. Data: `in_Troom` etc., sample time 30, *Interpolate data* off.
3. Add a **MATLAB Function** block named RiskEngine. Paste the text of the variable `blockCode` (run the first 40 lines of `ds_build_simulink.m` to create it).
4. Add four **To Workspace** blocks (`sl_state`, `sl_risk`, `sl_RHs`, `sl_margin`, format Timeseries) and a 4-input Scope. Connect.
5. In the Command Window: `S = ds_make_scenarios(30); d = S(3);` then `in_Troom = timeseries(d.Troom, d.t);` and so on for the other five, then press Run.

### 4.4 Circuit checks (T-H1 to T-H4)
```matlab
ds_circuit_check
```
Prints PASS/CHECK for the echo divider, MQ-135 divider, LED current, buzzer driver and power budget, and saves `circuit_echo_divider.png`, `circuit_mq135_divider.png`, `power_budget.csv`.

---

## 5. Optional Simscape Electrical circuit simulation

If you have Simscape Electrical, build the two dividers as a circuit for the report:
1. New model → add *Solver Configuration*, *Electrical Reference*, *DC Voltage Source* (5 V).
2. ECHO path: *Resistor* 1 kΩ in series, *Resistor* 2 kΩ to reference. Measure across the 2 kΩ with a *Voltage Sensor* → *PS-Simulink Converter* → *Scope*.
3. To show the pulse, replace the DC source with a *Controlled Voltage Source* driven by a Simulink *Pulse Generator* (amplitude 5, period 60 ms, pulse width 1 %) through a *Simulink-PS Converter*.
4. MQ-135 path: *Controlled Voltage Source* fed by a *Ramp* (0 → 5 V), 10 kΩ top, 14.7 kΩ bottom in parallel with 320 kΩ (the board's A0 divider). Sensor across the bottom resistor.
5. Screenshot both scopes. Expected: 3.33 V pulse; A0 rises linearly to ≈ 2.92 V at 5 V input.

---

## 6. Cloud central unit

1. *Apps > MATLAB Analysis > New > Custom (no starter code)*. Paste **all** of `thingspeak/ThingSpeak_CentralUnit.m`. Fill the configuration block (channel IDs, keys, HMAC key). Save and Run once: the output pane should print `state=… risk=…` and `command sent: …`.
2. *Apps > React > New React*: Condition type Numeric · Test frequency **On Data Insertion** · Channel DampSense-Telemetry · Field 8 (Sequence) · condition *is greater than* −1 · Action **MATLAB Analysis** → your analysis · *Run action each time condition is met*.
3. *Apps > MATLAB Visualizations > New > Custom*: paste `ThingSpeak_Visualization.m`, fill keys, tick *Display on channel* for DampSense-Analysis.
4. On Channel 1 and Channel 2, arrange the field charts and add Gauge widgets for Surface RH and Risk. Screenshot this dashboard.
5. For a short live demo set `WINDOW_MIN = 10` in the analysis; set it back to 60 for long runs.

Message budget (free licence, 3 million per year): at 60 s telemetry the system uses about 0.53 M (telemetry) + 0.53 M (analysis log) + 0.13 M (commands) ≈ 1.2 M per year. Use `DEMO_MODE 0` outside demonstrations.

---

## 7. Test execution and evidence checklist

| ID | Test | How | Evidence to capture |
|---|---|---|---|
| T-H1 | Divider voltages | Multimeter, section 2.3 + `ds_circuit_check` | Photo of meter, MATLAB output |
| T-F1 | Sensors read plausibly | Compare DHT22 with a reference thermometer/hygrometer for 30 min | Table of paired readings, mean error |
| T-F2 | Window detection | Open/close the model window 10 times | Field 4 chart, 10/10 correct |
| T-F3 | Occupancy | Walk in/out 10 times | Field 5 chart |
| T-F4 | Telemetry delivery | Run 24 h, read Analysis field 7 | Packet delivery % |
| T-F5–F9 | Decision logic | `ds_run_offline` | Seven figures + summary.csv |
| T-F10 | Simulink = reference | `ds_build_simulink` | simulink_vs_reference.csv, model screenshot |
| T-F11 | Live closed loop | Ice pack on DHT11 + breathe on DHT22 → RED; open window → VENTILATING | Video + Serial log + dashboard screenshot |
| T-P1 | End-to-end latency | Note Serial time of the `[TX]` that crosses the threshold and the `[CMD] accepted` line; repeat 10 times | Mean/max seconds |
| T-S0 | Crypto self-test | `ds_hmac_selftest` | Three PASS lines |
| T-S1 | Encryption on the wire | Laptop hotspot, Wireshark on the hotspot adapter, filter `ip.addr == <ESP IP>`. Capture with `USE_TLS 1`, then reflash with `USE_TLS 0` and capture again | Two screenshots: TLS 1.2 Application Data vs readable `field1=…` |
| T-S2 | Broker authentication | MQTTX: connect to mqtt3.thingspeak.com:8883 with a wrong password; then with the right device, try to publish to the Command channel | CONNACK refusal / publish rejected |
| T-S3a–f | Command integrity | Run `ds_security_tests` while watching Serial Monitor | Serial log showing accepted / replay / bad-mac / stale / format |
| T-S4 | Central unit resists junk | After T-S3, confirm the next heartbeat is still accepted | Serial `[CMD] accepted` line |
| T-R1 | Wi-Fi loss recovery | Switch hotspot off 2 min, then on | Serial reconnect log, no reboot, data gap only |
| T-R2 | Cloud loss fail-safe | Disable the React for 16 min | Amber flash = LINK_LOST on device |
| T-U1 | Usability | 3 people unfamiliar with the project read the LED legend and say what to do | Short notes: 3/3 understood |

---

## 8. Ten-minute demonstration script (presentation)

1. Show the board and dashboard: GREEN.
2. Hold a cold pack against the DHT11 "glass" and breathe/kettle-steam near the DHT22 → dashboard surface RH climbs → AMBER, then RED with buzzer.
3. Open the model window → VENTILATING within one cycle, buzzer stops.
4. Close window, remove cold pack → back to GREEN after the persistence window.
5. Security: show the Wireshark TLS capture, then run one forged command from `ds_security_tests` live — the device prints `REJECTED (bad-mac)` and the LEDs do not change.

---

## 9. Troubleshooting

| Symptom | Fix |
|---|---|
| `tls=` error on MQTT connect | Wrong root certificate or clock not synced. Re-export the **root** cert; check `NTP ok` appears |
| `rc=5` | MQTT credentials wrong or channel not authorised |
| Command channel updates but no `[CMD]` line | Device not authorised to Subscribe on Channel 3; buffer too small (keep `setBufferSize(1024)`) |
| Every command `REJECTED (bad-mac)` | HMAC key or DEVICE_ID differ between `secrets.h` and the analysis script |
| Every command `REJECTED (stale)` | Device clock wrong (NTP blocked on the network) |
| DHT reads NaN | Missing pull-up, or reading faster than every 2 s |
| HC-SR04 NaN | ECHO divider wrong way round, or sensor needs 5 V |
| React does not run the analysis | Check the React targets Field 8 and *each time condition is met* |
