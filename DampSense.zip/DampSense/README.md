# DampSense — secure IoT damp and mould early-warning system (CN7024)

| Folder | Contents |
|---|---|
| `firmware/DampSense_Node/` | ESP8266 Arduino sketch (`DampSense_Node.ino`) and `secrets_template.h` |
| `matlab/` | Shared risk engine (`ds_risk_engine.m`, `ds_default_params.m`), HMAC/SHA-256 + self-test, scenario generator, offline runner, Simulink model builder, circuit checks, security attack script |
| `thingspeak/` | `ThingSpeak_CentralUnit.m` (paste into MATLAB Analysis), `ThingSpeak_Visualization.m`, `build_thingspeak.sh` (regenerates the central-unit script from `matlab/`) |
| `docs/SIMULATION_GUIDE.md` | Step-by-step set-up, simulations, test plan and demo script |

Start with `docs/SIMULATION_GUIDE.md`.
