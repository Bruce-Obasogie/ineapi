/*
  =====================================================================
   DampSense Node - ESP8266 firmware                     CN7024 IoT
  =====================================================================
   Role : sensing + actuation node. It makes NO risk decisions.
          1. Reads 5 sensor types (DHT22 room, DHT11 cold spot, HC-SR04
             window gap, HC-SR501 occupancy, MQ-135 air index).
          2. Publishes telemetry to ThingSpeak over MQTT/TLS (port 8883).
          3. Subscribes to the Command channel; drives LEDs + buzzer ONLY
             for commands that pass HMAC-SHA256, freshness and
             anti-replay checks.

   Board    : LOLIN(WEMOS) D1 mini, or NodeMCU 1.0 (ESP-12E Module)
   Core     : esp8266 by ESP8266 Community (Boards Manager)
   Libraries: PubSubClient (Nick O'Leary) >= 2.8
              ArduinoJson (Benoit Blanchon) >= 7.0
              DHT sensor library (Adafruit) + Adafruit Unified Sensor
  =====================================================================
*/
#include <ESP8266WiFi.h>
#include <WiFiClientSecureBearSSL.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <DHT.h>
#include <time.h>
#include <bearssl/bearssl.h>
#include "secrets.h"

// ------------------------- Build options -----------------------------
#define USE_TLS    1   // 1 = MQTT over TLS :8883 (normal operation)
                       // 0 = plaintext :1883 - ONLY for security test T-S1 baseline capture
#define DEMO_MODE  1   // 1 = 20 s telemetry, 15 s re-beep (demonstration)
                       // 0 = 60 s telemetry, 5 min re-beep (deployment)

#if DEMO_MODE
const uint32_t PUBLISH_MS = 20000UL;   // ThingSpeak free licence minimum is 15 s
const uint32_t REBEEP_MS  = 15000UL;
#else
const uint32_t PUBLISH_MS = 60000UL;
const uint32_t REBEEP_MS  = 300000UL;
#endif
const uint32_t PIR_SAMPLE_MS   = 250UL;     // occupancy sampling period
const uint32_t LINK_LOST_MS    = 900000UL;  // 15 min with no valid command => link-lost
const long     CMD_MAX_AGE_S   = 300;       // reject commands older than 5 min

// --------------------- Pins (D1 mini / NodeMCU) ----------------------
const uint8_t PIN_DHT_ROOM = D5;  // DHT22 data
const uint8_t PIN_DHT_COLD = D6;  // DHT11 data (cold-spot probe on window frame)
const uint8_t PIN_PIR      = D7;  // HC-SR501 OUT (3.3 V logic)
const uint8_t PIN_TRIG     = D1;  // HC-SR04 TRIG
const uint8_t PIN_ECHO     = D2;  // HC-SR04 ECHO through 1k / 2k divider
const uint8_t PIN_BUZZER   = D8;  // NPN transistor base via 1k -> passive buzzer
const uint8_t PIN_LED_G    = D0;  // LEDs wired active-low: 3V3 -> 330R -> LED -> pin
const uint8_t PIN_LED_A    = D3;
const uint8_t PIN_LED_R    = D4;  // also the on-board LED
const uint8_t PIN_AIR      = A0;  // MQ-135 AOUT through 10k / 14.7k divider

// ------------------------- State codes -------------------------------
// Must match ds_default_params.m / ThingSpeak_CentralUnit.m
enum State : uint8_t { GREEN = 0, AMBER = 1, RED = 2, VENTILATING = 3,
                       ESCALATED = 4, FAULT = 5, LINK_LOST = 99 };

// ------------------------- Globals -----------------------------------
DHT dhtRoom(PIN_DHT_ROOM, DHT22);
DHT dhtCold(PIN_DHT_COLD, DHT11);

#if USE_TLS
BearSSL::WiFiClientSecure netClient;
BearSSL::X509List trustAnchor(CA_CERT_PEM);
const uint16_t MQTT_PORT = 8883;
#else
WiFiClient netClient;
const uint16_t MQTT_PORT = 1883;
#endif
PubSubClient mqtt(netClient);
const char* MQTT_HOST = "mqtt3.thingspeak.com";

uint8_t  currentState   = LINK_LOST;
uint32_t lastSeq        = 0;          // highest accepted command sequence
uint32_t lastValidCmdMs = 0;
uint32_t rejectedCount  = 0;          // security evidence, reported in status
uint32_t telemetrySeq   = 0;          // lets the cloud measure packet loss
uint32_t lastPublishMs  = 0, lastPirMs = 0, lastBeepMs = 0, lastBlinkMs = 0;
uint32_t pirHigh = 0, pirTotal = 0;
bool     blinkOn = false;

// ===================== Small helpers =================================
static void led(uint8_t pin, bool on) { digitalWrite(pin, on ? LOW : HIGH); } // active-low

static void beep(uint16_t ms) { tone(PIN_BUZZER, 2700, ms); }

static float medianOf(float* v, uint8_t n) {           // tiny insertion sort
  for (uint8_t i = 1; i < n; i++) {
    float k = v[i]; int8_t j = i - 1;
    while (j >= 0 && v[j] > k) { v[j + 1] = v[j]; j--; }
    v[j + 1] = k;
  }
  return v[n / 2];
}

// ===================== Sensors ======================================
float readGapCm() {                                     // median of 5 echoes
  float r[5]; uint8_t ok = 0;
  for (uint8_t i = 0; i < 5; i++) {
    digitalWrite(PIN_TRIG, LOW);  delayMicroseconds(2);
    digitalWrite(PIN_TRIG, HIGH); delayMicroseconds(10);
    digitalWrite(PIN_TRIG, LOW);
    unsigned long us = pulseIn(PIN_ECHO, HIGH, 25000UL); // ~4 m timeout
    if (us > 0) r[ok++] = us * 0.0343f / 2.0f;
    delay(30);
  }
  return ok >= 3 ? medianOf(r, ok) : NAN;
}

float readAirIndex() {                                  // 0..1023 relative index
  uint32_t s = 0;
  for (uint8_t i = 0; i < 16; i++) { s += analogRead(PIN_AIR); delay(5); }
  return s / 16.0f;
}

static bool plausibleT(float t)  { return !isnan(t) && t > -10 && t < 50; }
static bool plausibleRH(float h) { return !isnan(h) && h >= 0 && h <= 100; }

// ===================== Telemetry ====================================
void publishTelemetry() {
  float tRoom = dhtRoom.readTemperature();
  float hRoom = dhtRoom.readHumidity();
  float tCold = dhtCold.readTemperature();
  float gap   = readGapCm();
  float occ   = pirTotal ? (float)pirHigh / pirTotal : 0.0f;
  float air   = readAirIndex();
  pirHigh = pirTotal = 0;

  String p;                                             // fields omitted if invalid
  if (plausibleT(tRoom))  p += "field1=" + String(tRoom, 1) + "&";
  if (plausibleRH(hRoom)) p += "field2=" + String(hRoom, 1) + "&";
  if (plausibleT(tCold))  p += "field3=" + String(tCold, 1) + "&";
  if (!isnan(gap))        p += "field4=" + String(gap, 1) + "&";
  p += "field5=" + String(occ, 2) + "&";                // fraction only: data minimisation
  p += "field6=" + String(air, 0) + "&";
  p += "field7=" + String(WiFi.RSSI()) + "&";
  p += "field8=" + String(++telemetrySeq) + "&";
  p += "status=st" + String(currentState) + ";rej=" + String(rejectedCount);

  String topic = String("channels/") + TELEMETRY_CHANNEL_ID + "/publish";
  bool ok = mqtt.publish(topic.c_str(), p.c_str());
  Serial.printf("[TX] %s  %s  heap=%u\n", ok ? "ok" : "FAIL", p.c_str(), ESP.getFreeHeap());
}

// ===================== Command authentication ======================
static void hmacSha256Hex(const char* msg, char outHex[65]) {
  br_hmac_key_context kc;
  br_hmac_context hc;
  uint8_t mac[32];
  br_hmac_key_init(&kc, &br_sha256_vtable, HMAC_KEY, strlen(HMAC_KEY));
  br_hmac_init(&hc, &kc, 0);
  br_hmac_update(&hc, msg, strlen(msg));
  br_hmac_out(&hc, mac);
  for (uint8_t i = 0; i < 32; i++) sprintf(outHex + 2 * i, "%02x", mac[i]);
  outHex[64] = '\0';
}

static bool constTimeEq(const char* a, const char* b, size_t n) {
  uint8_t d = 0;
  for (size_t i = 0; i < n; i++) d |= (uint8_t)(tolower(a[i]) ^ tolower(b[i]));
  return d == 0;
}

static void reject(const char* why) {
  rejectedCount++;
  Serial.printf("[SEC] command REJECTED (%s), total=%u\n", why, rejectedCount);
}

// Command string (ThingSpeak Command channel, field1):
//   "<state>|<seq>|<unixTime>|<hmacHex>"
// HMAC-SHA256 is computed over "<DEVICE_ID>|<state>|<seq>|<unixTime>"
void handleCommand(const char* s) {
  unsigned int cmd; unsigned long seq, ts; char mac[65];
  if (sscanf(s, "%u|%lu|%lu|%64s", &cmd, &seq, &ts, mac) != 4 || strlen(mac) != 64) {
    reject("format"); return;
  }
  char signedPart[64], expect[65];
  snprintf(signedPart, sizeof(signedPart), "%s|%u|%lu|%lu", DEVICE_ID, cmd, seq, ts);
  hmacSha256Hex(signedPart, expect);
  if (!constTimeEq(mac, expect, 64))              { reject("bad-mac"); return; }

  time_t now = time(nullptr);
  if (now < 1700000000)                           { reject("no-clock"); return; }
  if (labs((long)now - (long)ts) > CMD_MAX_AGE_S) { reject("stale");    return; }
  if (lastSeq != 0 && seq <= lastSeq)             { reject("replay");   return; }
  if (cmd > FAULT)                                { reject("range");    return; }

  lastSeq = seq;
  lastValidCmdMs = millis();
  if (cmd != currentState) { lastBeepMs = 0; }    // new alert -> beep immediately
  currentState = cmd;
  Serial.printf("[CMD] accepted state=%u seq=%lu\n", cmd, seq);
}

void onMqttMessage(char* topic, byte* payload, unsigned int len) {
  JsonDocument doc;
  if (deserializeJson(doc, payload, len)) { reject("json"); return; }
  const char* f1 = doc["field1"] | "";
  handleCommand(f1);
}

// ===================== Actuators ===================================
void driveActuators() {
  uint32_t now = millis();
  if (now - lastBlinkMs >= 500) { lastBlinkMs = now; blinkOn = !blinkOn; }

  if (currentState != LINK_LOST && now - lastValidCmdMs > LINK_LOST_MS) currentState = LINK_LOST;

  bool g = false, a = false, r = false, wantBeep = false;
  switch (currentState) {
    case GREEN:       g = true;                         break;
    case AMBER:       a = true;                         break;
    case RED:         r = true; wantBeep = true;        break;
    case VENTILATING: r = blinkOn;                      break;  // window open: no buzzer
    case ESCALATED:   r = true; a = true; wantBeep = true; break;
    case FAULT:       a = blinkOn;                      break;
    default:          a = blinkOn && (now % 4000 < 500); break; // LINK_LOST: short amber flash
  }
  led(PIN_LED_G, g); led(PIN_LED_A, a); led(PIN_LED_R, r);

  if (wantBeep && (lastBeepMs == 0 || now - lastBeepMs >= REBEEP_MS)) {
    lastBeepMs = now; beep(400);
  }
}

// ===================== Connectivity ================================
void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("[NET] Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print('.'); driveActuators(); }
  Serial.printf(" ok %s RSSI %d\n", WiFi.localIP().toString().c_str(), WiFi.RSSI());
}

void syncClock() {                       // needed for TLS certificate checks and freshness
  configTime(0, 0, "pool.ntp.org", "time.google.com");
  Serial.print("[NET] NTP");
  while (time(nullptr) < 1700000000) { delay(300); Serial.print('.'); }
  Serial.println(" ok");
}

void connectMqtt() {
  uint16_t backoff = 2;
  while (!mqtt.connected()) {
    connectWiFi();
#if USE_TLS
    netClient.setX509Time(time(nullptr));
#endif
    Serial.printf("[MQTT] %s:%u ... ", MQTT_HOST, MQTT_PORT);
    if (mqtt.connect(MQTT_CLIENT_ID, MQTT_USERNAME, MQTT_PASSWORD)) {
      String sub = String("channels/") + COMMAND_CHANNEL_ID + "/subscribe";
      mqtt.subscribe(sub.c_str());
      Serial.printf("connected, subscribed %s\n", sub.c_str());
    } else {
#if USE_TLS
      char err[80]; netClient.getLastSSLError(err, sizeof(err));
      Serial.printf("failed rc=%d tls=%s, retry in %us\n", mqtt.state(), err, backoff);
#else
      Serial.printf("failed rc=%d, retry in %us\n", mqtt.state(), backoff);
#endif
      uint32_t t0 = millis();
      while (millis() - t0 < backoff * 1000UL) { driveActuators(); delay(20); }
      if (backoff < 60) backoff *= 2;
    }
  }
}

// ===================== Arduino entry points =========================
void setup() {
  Serial.begin(115200); delay(200);
  Serial.println("\n=== DampSense node " DEVICE_ID " ===");
  pinMode(PIN_LED_G, OUTPUT); pinMode(PIN_LED_A, OUTPUT); pinMode(PIN_LED_R, OUTPUT);
  led(PIN_LED_G, false); led(PIN_LED_A, false); led(PIN_LED_R, false);
  pinMode(PIN_TRIG, OUTPUT); pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_PIR, INPUT);   pinMode(PIN_BUZZER, OUTPUT); digitalWrite(PIN_BUZZER, LOW);
  dhtRoom.begin(); dhtCold.begin();

  connectWiFi();
  syncClock();
#if USE_TLS
  netClient.setTrustAnchors(&trustAnchor);   // verify the broker certificate chain
#endif
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setBufferSize(1024);                   // subscription JSON exceeds the 256 B default
  mqtt.setCallback(onMqttMessage);
  mqtt.setKeepAlive(60);
  connectMqtt();
  lastValidCmdMs = millis();                  // grace period before LINK_LOST
}

void loop() {
  if (!mqtt.connected()) connectMqtt();
  mqtt.loop();

  uint32_t now = millis();
  if (now - lastPirMs >= PIR_SAMPLE_MS) {
    lastPirMs = now; pirTotal++;
    if (digitalRead(PIN_PIR) == HIGH) pirHigh++;
  }
  if (now - lastPublishMs >= PUBLISH_MS) { lastPublishMs = now; publishTelemetry(); }
  driveActuators();
}
