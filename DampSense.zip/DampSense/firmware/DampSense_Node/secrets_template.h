// =====================================================================
//  DampSense - secrets_template.h
//  Copy this file to "secrets.h" in the same folder and fill in your values.
//  secrets.h is listed in .gitignore and must NEVER be committed.
// =====================================================================
#pragma once

// ---- Wi-Fi ----
#define WIFI_SSID        "YOUR_WIFI_SSID"
#define WIFI_PASS        "YOUR_WIFI_PASSWORD"

// ---- ThingSpeak MQTT device (Devices > MQTT > Add a new device) ----
// Authorise: Telemetry channel = Publish ONLY, Command channel = Subscribe ONLY.
#define MQTT_CLIENT_ID   "YOUR_MQTT_CLIENT_ID"
#define MQTT_USERNAME    "YOUR_MQTT_USERNAME"
#define MQTT_PASSWORD    "YOUR_MQTT_PASSWORD"

// ---- Channel numbers ----
#define TELEMETRY_CHANNEL_ID  "0000000"   // Channel 1: DampSense-Telemetry
#define COMMAND_CHANNEL_ID    "0000000"   // Channel 3: DampSense-Command

// ---- Command authentication ----
// Device identity (bound into every signed command) and the shared HMAC key.
// Generate the key in MATLAB:  key = char(randi([48 57],1,32))  or any 32+ random characters.
// The SAME string must be pasted into ThingSpeak_CentralUnit.m (HMAC_KEY).
#define DEVICE_ID        "DS01"
#define HMAC_KEY         "k3y-CHANGE-ME-32-chars-long-0001"

// ---- TLS trust anchor for mqtt3.thingspeak.com ----
// Paste the ROOT certificate of the chain that thingspeak.com presents (PEM).
// How: open https://thingspeak.com in a browser > padlock > certificate > Details/Certification
// Path > select the TOP (root) certificate > Export as Base-64 / PEM > paste below.
static const char CA_CERT_PEM[] = R"EOF(
-----BEGIN CERTIFICATE-----
PASTE_ROOT_CERTIFICATE_HERE
-----END CERTIFICATE-----
)EOF";
