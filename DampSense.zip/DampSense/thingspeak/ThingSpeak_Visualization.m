%% DampSense - ThingSpeak MATLAB Visualization (landlord / tenant view)
% Apps > MATLAB Visualizations > New > Custom. Add it to the Analysis
% channel view. Shows the last 24 h: surface RH vs the 80 % mould line,
% risk score and the decided state.

CH_ANALYSIS = 0000000;  READ_KEY_ANALYSIS = 'XXXXXXXXXXXXXXXX';
[d, t] = thingSpeakRead(CH_ANALYSIS, 'Fields', [2 4 5], 'NumMinutes', 1440, ...
                        'ReadKey', READ_KEY_ANALYSIS, 'OutputFormat', 'matrix');
tiledlayout(3, 1, 'TileSpacing', 'compact');
nexttile; plot(t, d(:,1), 'LineWidth', 1.2); yline(80, '--', 'Mould threshold 80%');
ylabel('Surface RH (%)'); grid on; title('DampSense - last 24 hours');
nexttile; area(t, d(:,2), 'FaceAlpha', 0.3); yline(40, ':', 'Amber'); yline(70, ':', 'Red');
ylabel('Risk'); ylim([0 100]); grid on;
nexttile; stairs(t, d(:,3), 'LineWidth', 1.5);
yticks(0:5); yticklabels({'GREEN','AMBER','RED','VENT','ESC','FAULT'}); ylim([-0.5 5.5]); grid on;
