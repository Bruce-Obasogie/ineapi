#!/bin/sh
# Rebuild the self-contained ThingSpeak script from the shared MATLAB sources.
cd "$(dirname "$0")"
OUT=ThingSpeak_CentralUnit.m
cat central_unit_main.m.part > $OUT
for f in ds_default_params ds_risk_engine ds_hmac_sha256 ds_sha256; do
  printf '\n%%%% ---- %s.m ----\n' "$f" >> $OUT
  cat ../matlab/$f.m >> $OUT
done
echo "wrote $OUT"
