%% =====================================================================
%  DampSense CENTRAL UNIT - ThingSpeak MATLAB Analysis
%  CN7024 Internet of Things
%  ---------------------------------------------------------------------
%  Triggered by a React app "On Data Insertion" on the Telemetry channel.
%  1. Reads the last 60 min of telemetry (Channel 1).
%  2. Runs the DampSense risk engine (same code as MATLAB/Simulink).
%  3. Logs derived values to the Analysis channel (Channel 2) for dashboards.
%  4. Sends an HMAC-SHA256-signed command to the Command channel (Channel 3)
%     when the state changes, plus a heartbeat every 4 minutes.
%  5. Optionally e-mails the landlord when the state becomes ESCALATED.
%  Self-contained: all helper functions are at the end of this script.
%  GENERATED FILE - edit the sources in /matlab and rebuild with build_thingspeak.sh
%% =====================================================================

% ------------------------------ Configuration ---------------------------
CH_TELEMETRY   = 0000000;  READ_KEY_TELEMETRY = 'XXXXXXXXXXXXXXXX';
CH_ANALYSIS    = 0000000;  READ_KEY_ANALYSIS  = 'XXXXXXXXXXXXXXXX';
                           WRITE_KEY_ANALYSIS = 'XXXXXXXXXXXXXXXX';
CH_COMMAND     = 0000000;  READ_KEY_COMMAND   = 'XXXXXXXXXXXXXXXX';
                           WRITE_KEY_COMMAND  = 'XXXXXXXXXXXXXXXX';
DEVICE_ID      = 'DS01';
HMAC_KEY       = 'k3y-CHANGE-ME-32-chars-long-0001';   % same as firmware secrets.h
ALERTS_KEY     = '';      % optional ThingSpeak Alerts API key; '' disables e-mail
WINDOW_MIN     = 60;      % analysis window (use 10 for a short live demo)
HEARTBEAT_S    = 240;     % resend the current state at least this often
tStart = tic;
P = ds_default_params();

% ------------------------------ 1. Telemetry ----------------------------
[X, tX] = thingSpeakRead(CH_TELEMETRY, 'Fields', 1:8, 'NumMinutes', WINDOW_MIN, ...
                         'ReadKey', READ_KEY_TELEMETRY, 'OutputFormat', 'matrix');
if isempty(X)
    X = nan(1, 8); tX = datetime('now', 'TimeZone', 'UTC');   % no data => FAULT
end
Troom = X(:,1); RHroom = X(:,2); Tcold = X(:,3); gap = X(:,4);
occ   = X(:,5); air    = X(:,6); seq   = X(:,8);

% Packet delivery ratio from the node's sequence counter (reliability KPI)
s = seq(~isnan(seq));
if numel(s) >= 2 && s(end) > s(1)
    pdr = 100 * numel(s) / (s(end) - s(1) + 1);
else
    pdr = NaN;
end

% ------------------------------ 2. Context ------------------------------
% Previous AUTHENTIC command (hysteresis, sequence number, heartbeat timing).
% The central unit re-verifies its own history, so junk or forged entries
% written to the Command channel cannot reset its sequence counter.
prevState = P.GREEN; lastSeq = 0; lastTs = 0;
try
    r = webread(sprintf('https://api.thingspeak.com/channels/%d/feeds.json', CH_COMMAND), ...
                'api_key', READ_KEY_COMMAND, 'results', 30);
    feeds = r.feeds;
    if ~iscell(feeds), feeds = num2cell(feeds); end
    for i = 1:numel(feeds)
        c = strsplit(char(feeds{i}.field1), '|');
        if numel(c) ~= 4, continue; end
        v = str2double(c(1:3));
        good = all(~isnan(v)) && strcmp(c{4}, ds_hmac_sha256(HMAC_KEY, ...
                   sprintf('%s|%d|%d|%d', DEVICE_ID, v(1), v(2), v(3))));
        if good && v(2) > lastSeq
            prevState = v(1); lastSeq = v(2); lastTs = v(3);
        end
    end
catch
    % empty channel on first run
end

% Hours at RED-level risk in the last 24 h (escalation rule)
hoursHigh = 0;
try
    [rk, tr] = thingSpeakRead(CH_ANALYSIS, 'Fields', 4, 'NumMinutes', 1440, ...
                              'ReadKey', READ_KEY_ANALYSIS, 'OutputFormat', 'matrix');
    if numel(rk) >= 2
        dt = min(seconds(diff(tr)), 300);                % cap gaps at 5 min
        hoursHigh = sum(dt(rk(1:end-1) >= P.redOn)) / 3600;
    end
catch
end

% ------------------------------ 3. Decide -------------------------------
[state, risk, Td, RHs, margin] = ds_risk_engine(Troom, RHroom, Tcold, gap, occ, air, ...
                                                prevState, hoursHigh, P);
tLast = tX(end);
if isempty(tLast.TimeZone), tLast.TimeZone = 'UTC'; end      % ThingSpeak servers use UTC
latency = seconds(datetime('now', 'TimeZone', 'UTC') - tLast);   % data age at decision
fprintf('state=%d risk=%.1f Td=%.1f RHs=%.1f margin=%.1f hh=%.2f pdr=%.1f\n', ...
        state, risk, Td, RHs, margin, hoursHigh, pdr);

% ------------------------------ 4. Log ----------------------------------
tsUpdate(WRITE_KEY_ANALYSIS, [Td, RHs, margin, risk, state, hoursHigh, pdr, latency]);

% ------------------------------ 5. Command ------------------------------
nowS = floor(posixtime(datetime('now', 'TimeZone', 'UTC')));
if state ~= prevState || nowS - lastTs >= HEARTBEAT_S
    seqN   = lastSeq + 1;
    signed = sprintf('%s|%d|%d|%d', DEVICE_ID, state, seqN, nowS);
    mac    = ds_hmac_sha256(HMAC_KEY, signed);
    cmdStr = sprintf('%d|%d|%d|%s', state, seqN, nowS, mac);
    webwrite('https://api.thingspeak.com/update', 'api_key', WRITE_KEY_COMMAND, 'field1', cmdStr);
    fprintf('command sent: %s\n', cmdStr);
end

% ------------------------------ 6. Escalation e-mail --------------------
if state == P.ESCALATED && prevState ~= P.ESCALATED && ~isempty(ALERTS_KEY)
    try
        opts = weboptions('HeaderFields', {'ThingSpeak-Alerts-API-Key', ALERTS_KEY}, ...
                          'MediaType', 'application/json');
        webwrite('https://api.thingspeak.com/alerts/send', ...
                 struct('subject', 'DampSense: persistent mould risk', ...
                        'body', sprintf(['Device %s has been at high condensation risk for ' ...
                                         '%.1f h in the last 24 h. Surface RH %.0f%%.'], ...
                                        DEVICE_ID, hoursHigh, RHs)), opts);
    catch err
        fprintf('alert not sent: %s\n', err.message);
    end
end
fprintf('run time %.2f s\n', toc(tStart));

%% ============================ Helper functions ==========================
function tsUpdate(key, v)
% Write a row to a channel, leaving out NaN fields.
args = {'api_key', key};
for i = 1:numel(v)
    if ~isnan(v(i))
        args = [args, {sprintf('field%d', i), sprintf('%.2f', v(i))}]; %#ok<AGROW>
    end
end
webwrite('https://api.thingspeak.com/update', args{:});
end


%% ---- ds_default_params.m ----
function P = ds_default_params()
%DS_DEFAULT_PARAMS  Tunable parameters of the DampSense risk engine.
%   One source of truth for MATLAB, Simulink and (copied into) ThingSpeak.
%#codegen

% --- Magnus dew-point constants (over water, -45..60 C; Alduchov & Eskridge 1996)
P.a = 17.62;
P.b = 243.12;            % degC

% --- Surface-humidity scoring
P.rhsLow   = 65;         % % surface RH that starts to score
P.rhsHigh  = 90;         % % surface RH that scores 100
P.mouldRH  = 80;         % % IEA Annex 14 germination threshold (sustained)

% --- Air staleness (MQ-135 relative index)
P.airSpan  = 0.5;        % +50 % above the window baseline scores 100

% --- Weights (sum to 1)
P.wS = 0.50;             % surface RH now
P.wP = 0.35;             % persistence of surface RH >= mouldRH in window
P.wV = 0.15;             % air staleness

% --- State thresholds with hysteresis
P.amberOn  = 40;  P.amberOff = 30;
P.redOn    = 70;  P.redOff   = 60;

% --- Context
P.gapOpenCm     = 20;    % HC-SR04 reading above this = window open (calibrate on your build)
P.occRecentN    = 20;    % samples checked for occupancy (20 x 30 s = 10 min)
P.occMinFrac    = 0.05;  % PIR high fraction counted as "occupied"
P.escalateHours = 6;     % RED-level hours in the last 24 h that trigger escalation
P.minValid      = 3;     % valid samples needed, otherwise FAULT

% --- State codes (must match firmware enum)
P.GREEN = 0; P.AMBER = 1; P.RED = 2; P.VENTILATING = 3; P.ESCALATED = 4; P.FAULT = 5;
end

%% ---- ds_risk_engine.m ----
function [state, risk, TdNow, RHsNow, marginNow] = ds_risk_engine( ...
            Troom, RHroom, Tcold, gap, occ, air, prevState, hoursHigh24, P)
%DS_RISK_ENGINE  DampSense central decision logic (pure function, no I/O).
%
%   Inputs are column vectors covering the analysis window, oldest first.
%   NaN marks a missing reading. prevState is the last state sent to the
%   device (for hysteresis); hoursHigh24 is how long risk was >= P.redOn in
%   the last 24 h.
%
%   Outputs: state code (see ds_default_params), risk score 0..100,
%   current dew point TdNow (degC), surface RH at the cold spot RHsNow (%)
%   and condensation margin marginNow = Tcold - Td (degC).
%
%   Used unchanged by: ds_run_offline.m (MATLAB), the Simulink model
%   (MATLAB Function block) and ThingSpeak_CentralUnit.m (cloud).
%#codegen

risk = NaN; TdNow = NaN; RHsNow = NaN; marginNow = NaN;

valid = ~isnan(Troom) & ~isnan(RHroom) & ~isnan(Tcold);
n = numel(valid);
lastK = max(1, n - 2):n;                       % newest 3 samples
if sum(valid) < P.minValid || ~any(valid(lastK))
    state = P.FAULT;
    return;
end

% ---- Psychrometrics -----------------------------------------------------
rh    = min(max(RHroom, 1), 100);
gam   = log(rh / 100) + P.a .* Troom ./ (P.b + Troom);
Td    = P.b .* gam ./ (P.a - gam);                                   % dew point
RHs   = 100 .* exp(P.a .* Td ./ (P.b + Td)) ./ exp(P.a .* Tcold ./ (P.b + Tcold));
RHs   = min(RHs, 100);                                               % >=100 => condensing
Td(~valid) = NaN;  RHs(~valid) = NaN;

idx       = lastK(valid(lastK));
RHsNow    = median(RHs(idx));
TdNow     = median(Td(idx));
marginNow = median(Tcold(idx)) - TdNow;

% ---- Component scores ---------------------------------------------------
Sa = min(max((RHsNow - P.rhsLow) / (P.rhsHigh - P.rhsLow) * 100, 0), 100);
Sp = 100 * sum(RHs(valid) >= P.mouldRH) / sum(valid);

Sv = 0;
va = air(~isnan(air));
if numel(va) >= 3
    s    = sort(va);
    base = s(max(1, ceil(0.1 * numel(s))));     % 10th percentile = fresh-air baseline
    aNow = median(va(max(1, numel(va) - 2):end));
    Sv   = min(max((aNow - base) / max(base, 1) / P.airSpan * 100, 0), 100);
end

risk = P.wS * Sa + P.wP * Sp + P.wV * Sv;

% ---- Level with hysteresis ----------------------------------------------
prevLevel = 0;
if prevState == P.AMBER
    prevLevel = 1;
elseif prevState == P.RED || prevState == P.ESCALATED || prevState == P.VENTILATING
    prevLevel = 2;
end
level = 0;
if risk >= P.redOn
    level = 2;
elseif risk >= P.amberOn
    level = 1;
end
if prevLevel == 2 && level < 2 && risk >= P.redOff
    level = 2;
end
if prevLevel >= 1 && level == 0 && risk >= P.amberOff
    level = 1;
end

% ---- Context: window and occupancy --------------------------------------
g = gap(lastK); g = g(~isnan(g));
windowOpen = ~isempty(g) && median(g) > P.gapOpenCm;
o = occ(max(1, numel(occ) - P.occRecentN + 1):end);
o = o(~isnan(o));
occupied = ~isempty(o) && any(o > P.occMinFrac);

% ---- Decision -----------------------------------------------------------
if level == 0
    state = P.GREEN;
elseif windowOpen
    state = P.VENTILATING;                 % occupant already acting: no buzzer
elseif level == 2 && hoursHigh24 >= P.escalateHours
    state = P.ESCALATED;                   % persistent problem: notify landlord
elseif level == 2 && occupied
    state = P.RED;                         % someone present who can ventilate
else
    state = P.AMBER;                       % rising risk, or high risk but nobody home
end
end

%% ---- ds_hmac_sha256.m ----
function hexMac = ds_hmac_sha256(key, msg)
%DS_HMAC_SHA256  HMAC-SHA256 (RFC 2104) returning a lowercase hex string.
%   hexMac = ds_hmac_sha256('secret', 'DS01|2|17|1762700000')

key = uint8(key(:)');
msg = uint8(msg(:)');
if numel(key) > 64
    key = ds_sha256(key);
end
key  = [key, zeros(1, 64 - numel(key), 'uint8')];
ipad = bitxor(key, uint8(54));      % 0x36
opad = bitxor(key, uint8(92));      % 0x5c
inner  = ds_sha256([ipad, msg]);
mac    = ds_sha256([opad, inner]);
hexMac = lower(reshape(dec2hex(mac, 2)', 1, []));
end

%% ---- ds_sha256.m ----
function digest = ds_sha256(msg)
%DS_SHA256  SHA-256 (FIPS 180-4) in plain MATLAB, no toolboxes or Java.
%   digest = ds_sha256(msg) returns a 1x32 uint8 digest of msg (char or uint8).
%   Written so it also runs inside ThingSpeak MATLAB Analysis.
%   Check with ds_hmac_selftest.

msg = uint8(msg(:)');
K = uint32(hex2dec({ ...
 '428a2f98','71374491','b5c0fbcf','e9b5dba5','3956c25b','59f111f1','923f82a4','ab1c5ed5', ...
 'd807aa98','12835b01','243185be','550c7dc3','72be5d74','80deb1fe','9bdc06a7','c19bf174', ...
 'e49b69c1','efbe4786','0fc19dc6','240ca1cc','2de92c6f','4a7484aa','5cb0a9dc','76f988da', ...
 '983e5152','a831c66d','b00327c8','bf597fc7','c6e00bf3','d5a79147','06ca6351','14292967', ...
 '27b70a85','2e1b2138','4d2c6dfc','53380d13','650a7354','766a0abb','81c2c92e','92722c85', ...
 'a2bfe8a1','a81a664b','c24b8b70','c76c51a3','d192e819','d6990624','f40e3585','106aa070', ...
 '19a4c116','1e376c08','2748774c','34b0bcb5','391c0cb3','4ed8aa4a','5b9cca4f','682e6ff3', ...
 '748f82ee','78a5636f','84c87814','8cc70208','90befffa','a4506ceb','bef9a3f7','c67178f2'}))';
H = uint32(hex2dec({'6a09e667','bb67ae85','3c6ef372','a54ff53a', ...
                    '510e527f','9b05688c','1f83d9ab','5be0cd19'}))';

% ---- Padding ----
L = numel(msg);
bitLen = L * 8;
lenBytes = zeros(1, 8, 'uint8');
for i = 1:8
    lenBytes(9 - i) = uint8(mod(floor(bitLen / 256^(i - 1)), 256));
end
msg = [msg, uint8(128), zeros(1, mod(55 - L, 64), 'uint8'), lenBytes];

% ---- Compression ----
for blk = 0:(numel(msg) / 64 - 1)
    B = double(msg(blk * 64 + (1:64)));
    W = zeros(1, 64, 'uint32');
    for t = 1:16
        W(t) = uint32(B(4*t-3) * 16777216 + B(4*t-2) * 65536 + B(4*t-1) * 256 + B(4*t));
    end
    for t = 17:64
        s0 = bitxor(bitxor(rotr(W(t-15), 7), rotr(W(t-15), 18)), bitshift(W(t-15), -3));
        s1 = bitxor(bitxor(rotr(W(t-2), 17), rotr(W(t-2), 19)), bitshift(W(t-2), -10));
        W(t) = add32(W(t-16), s0, W(t-7), s1);
    end
    a = H(1); b = H(2); c = H(3); d = H(4); e = H(5); f = H(6); g = H(7); h = H(8);
    for t = 1:64
        S1  = bitxor(bitxor(rotr(e, 6), rotr(e, 11)), rotr(e, 25));
        ch  = bitxor(bitand(e, f), bitand(bitcmp(e), g));
        T1  = add32(h, S1, ch, K(t), W(t));
        S0  = bitxor(bitxor(rotr(a, 2), rotr(a, 13)), rotr(a, 22));
        maj = bitxor(bitxor(bitand(a, b), bitand(a, c)), bitand(b, c));
        T2  = add32(S0, maj);
        h = g; g = f; f = e; e = add32(d, T1);
        d = c; c = b; b = a; a = add32(T1, T2);
    end
    H = [add32(H(1), a), add32(H(2), b), add32(H(3), c), add32(H(4), d), ...
         add32(H(5), e), add32(H(6), f), add32(H(7), g), add32(H(8), h)];
end

% ---- Output big-endian bytes ----
digest = zeros(1, 32, 'uint8');
for i = 1:8
    v = double(H(i));
    digest(4*i-3:4*i) = uint8([floor(v / 16777216), mod(floor(v / 65536), 256), ...
                               mod(floor(v / 256), 256), mod(v, 256)]);
end
end

function y = rotr(x, n)
% 32-bit rotate right. The low n bits are masked before the left shift so
% nothing can overflow 32 bits, whatever the MATLAB release.
lowBits = bitand(x, uint32(2^n - 1));
y = bitor(bitshift(x, -n), bitshift(lowBits, 32 - n));
end

function s = add32(varargin)
% Addition modulo 2^32 (uint32 '+' would saturate, so add in double).
acc = 0;
for k = 1:nargin
    acc = acc + double(varargin{k});
end
s = uint32(mod(acc, 4294967296));
end
